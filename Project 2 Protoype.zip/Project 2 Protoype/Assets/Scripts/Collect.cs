using UnityEngine;

public class Collect : MonoBehaviour
{
    public float holdDuration = 5f;
    private float timer = 0f;
    private bool collected = false;

    // Called every frame by the player while looking at + holding on this object
    public void Hold()
    {
        if (collected) return;

        timer += Time.deltaTime;
        if (timer >= holdDuration)
        {
            collected = true;
            Debug.Log("Object collected");
            GameControl.instance.Scored();
            Destroy(gameObject); // destroy
        }
    }

    // Called when the player stops looking at it or releases the button
    public void ResetHold()
    {
        timer = 0f;
    }
}