using UnityEngine;

public class Interactor : MonoBehaviour
{
    public float reach = 4f;
    private Collect current;

    void Update()
    {
        Collect target = null;

        if (Input.GetMouseButton(0))
        {
            Ray ray = new Ray(transform.position, transform.forward);
            if (Physics.Raycast(ray, out RaycastHit hit, reach))
            {
                target = hit.collider.GetComponentInParent<Collect>();
            }
        }

        // Switched targets or let go: reset the old one
        if (current != null && current != target)
            current.ResetHold();

        current = target;

        if (current != null)
            current.Hold();
    }
}