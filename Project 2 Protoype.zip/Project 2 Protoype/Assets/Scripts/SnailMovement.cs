using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SnailMovement : MonoBehaviour
{

    public Transform player;
    private UnityEngine.AI.NavMeshAgent navMeshAgent;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        navMeshAgent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        StartCoroutine(IncreaseSpeed());
    }

    // Update is called once per frame
    void Update()
    {
        if (player != null)
        {
            navMeshAgent.SetDestination(player.position);
        } else if (player == null)
        {
            Debug.Log("player not found");
        }
    }

    IEnumerator IncreaseSpeed()
    {
        yield return new WaitForSeconds(5f);
        navMeshAgent.speed += .1f;
    }


}
