using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class HandleCollide : MonoBehaviour
{

    private float delay = 1f;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Snail")
        {
            Die();
        }
    }

    void Die()
    {
        Debug.Log("Died");
        GameControl.instance.GameOver();
        StartCoroutine(Restart(delay));
    }

    IEnumerator Restart(float delay)
    {
        yield return new WaitForSeconds(delay);
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
