using UnityEngine;

public class DoorBehavior : MonoBehaviour
{

    public static DoorBehavior instance;

    
    void Awake()
    {
        instance = this;
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    
    // Update is called once per frame
    public void OpenDoor()
    {
        Destroy(gameObject);
    }
}
